-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2015 at 10:17 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `factorydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `daily_sales`
--

CREATE TABLE IF NOT EXISTS `daily_sales` (
  `DAYNAME` varchar(32) NOT NULL,
  `MONTHNAME` varchar(32) NOT NULL,
  `ROUND` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_sales`
--

INSERT INTO `daily_sales` (`DAYNAME`, `MONTHNAME`, `ROUND`) VALUES
('Sunday', 'January', 6),
('Monday', 'January', 9),
('Tuesday', 'January', 12),
('Wednesday', 'January', 4),
('Thursday', 'January', 13),
('Friday', 'January', 10),
('Saturday', 'January', 7);

-- --------------------------------------------------------

--
-- Table structure for table `drag`
--

CREATE TABLE IF NOT EXISTS `drag` (
  `id` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drag`
--

INSERT INTO `drag` (`id`, `Name`) VALUES
(0, 'A'),
(1, 'B'),
(2, 'C'),
(3, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `factory_detail`
--

CREATE TABLE IF NOT EXISTS `factory_detail` (
  `FactoryName` varchar(50) NOT NULL,
  `ItemName` varchar(20) NOT NULL,
  `Quarter` varchar(10) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factory_detail`
--

INSERT INTO `factory_detail` (`FactoryName`, `ItemName`, `Quarter`, `Quantity`) VALUES
('Factory1', 'Toy', 'Q1', 190),
('Factory1', 'Choclates', 'Q1', 100),
('Factory1', 'Chips', 'Q1', 200),
('Factory1', 'Toy', 'Q2', 190),
('Factory1', 'Choclates', 'Q2', 100),
('Factory1', 'Chips', 'Q2', 200),
('Factory2', 'Toy', 'Q2', 190),
('Factory2', 'Choclates', 'Q2', 100),
('Factory2', 'Chips', 'Q2', 200),
('Factory3', 'Toy', 'Q2', 190),
('Factory3', 'Choclates', 'Q2', 100),
('Factory3', 'Chips', 'Q2', 200),
('Factory2', 'Toy', 'Q1', 190),
('Factory2', 'Chips', 'Q1', 100),
('Factory2', 'Choclates', 'Q1', 200),
('Factory3', 'Toy', 'Q1', 190),
('Factory3', 'Choclates', 'Q1', 100),
('Factory3', 'Chips', 'Q1', 200),
('Factory1', 'Toy', 'Q3', 190),
('Factory1', 'Choclates', 'Q3', 100),
('Factory1', 'Chips', 'Q3', 200),
('Factory2', 'Toy', 'Q3', 190),
('Factory2', 'Choclates', 'Q3', 100),
('Factory2', 'Chips', 'Q3', 200),
('Factory3', 'Toy', 'Q3', 190),
('Factory3', 'Choclates', 'Q3', 100),
('Factory3', 'Chips', 'Q3', 200);

-- --------------------------------------------------------

--
-- Table structure for table `factory_master`
--

CREATE TABLE IF NOT EXISTS `factory_master` (
  `FactoryId` int(11) NOT NULL AUTO_INCREMENT,
  `FactoryName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`FactoryId`),
  KEY `FactoryName` (`FactoryName`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `factory_master`
--

INSERT INTO `factory_master` (`FactoryId`, `FactoryName`) VALUES
(1, 'Factory1'),
(2, 'Factory2'),
(3, 'Factory3');

-- --------------------------------------------------------

--
-- Table structure for table `factory_output`
--

CREATE TABLE IF NOT EXISTS `factory_output` (
  `FactoryID` int(11) DEFAULT '0',
  `DatePro` datetime DEFAULT NULL,
  `Quantity` double DEFAULT NULL,
  KEY `FactoryID` (`FactoryID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factory_output`
--

INSERT INTO `factory_output` (`FactoryID`, `DatePro`, `Quantity`) VALUES
(1, '2003-01-01 17:53:26', 21),
(1, '2003-01-02 17:54:13', 23),
(1, '2003-01-03 17:54:14', 22),
(1, '2003-01-04 17:54:21', 24),
(1, '2003-01-05 17:54:45', 32),
(1, '2003-01-06 17:54:53', 21),
(1, '2003-01-07 17:54:58', 34),
(1, '2003-01-08 17:55:04', 32),
(1, '2003-01-09 17:55:15', 32),
(1, '2003-01-10 17:55:20', 23),
(1, '2003-01-11 17:55:26', 23),
(1, '2003-01-12 17:55:35', 32),
(1, '2003-01-13 17:55:40', 53),
(1, '2003-01-14 17:55:44', 23),
(1, '2003-01-15 17:55:51', 26),
(1, '2003-01-16 17:55:58', 43),
(1, '2003-01-17 17:56:04', 16),
(1, '2003-01-18 17:56:09', 45),
(1, '2003-01-19 17:56:15', 65),
(1, '2003-01-20 17:56:22', 54),
(2, '2003-01-01 17:53:26', 121),
(2, '2003-01-02 17:54:13', 123),
(2, '2003-01-03 17:54:14', 122),
(2, '2003-01-04 17:54:21', 124),
(2, '2003-01-05 17:54:45', 132),
(2, '2003-01-06 17:54:53', 121),
(2, '2003-01-07 17:54:58', 134),
(2, '2003-01-08 17:55:04', 132),
(2, '2003-01-09 17:55:15', 132),
(2, '2003-01-10 17:55:20', 123),
(2, '2003-01-11 17:55:26', 123),
(2, '2003-01-12 17:55:35', 132),
(2, '2003-01-13 17:55:40', 153),
(2, '2003-01-14 17:55:44', 123),
(2, '2003-01-15 17:55:51', 126),
(2, '2003-01-16 17:55:58', 143),
(2, '2003-01-17 17:56:04', 116),
(2, '2003-01-18 17:56:09', 145),
(2, '2003-01-19 17:56:15', 165),
(2, '2003-01-20 17:56:22', 154),
(3, '2003-01-01 17:53:26', 54),
(3, '2003-01-02 17:54:13', 56),
(3, '2003-01-03 17:54:14', 89),
(3, '2003-01-04 17:54:21', 56),
(3, '2003-01-05 17:54:45', 98),
(3, '2003-01-06 17:54:53', 76),
(3, '2003-01-07 17:54:58', 65),
(3, '2003-01-08 17:55:04', 45),
(3, '2003-01-09 17:55:15', 75),
(3, '2003-01-10 17:55:20', 54),
(3, '2003-01-11 17:55:26', 75),
(3, '2003-01-12 17:55:35', 76),
(3, '2003-01-13 17:55:40', 34),
(3, '2003-01-14 17:55:44', 97),
(3, '2003-01-15 17:55:51', 55),
(3, '2003-01-16 17:55:58', 43),
(3, '2003-01-17 17:56:04', 16),
(3, '2003-01-18 17:56:09', 35),
(3, '2003-01-19 17:56:15', 78),
(3, '2003-01-20 17:56:22', 75);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
