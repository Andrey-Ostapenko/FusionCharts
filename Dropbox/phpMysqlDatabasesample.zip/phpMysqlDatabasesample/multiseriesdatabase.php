<?php
      //We have included ../Includes/FusionCharts.php, which contains functions
      //to help us easily embed the charts.
      include("class/Includes/FusionCharts.php");
	  include("class/Includes/DBConn.php");
      ?>
      <HTML>
         <HEAD>
        <TITLE> FusionCharts XT - </TITLE>
        <SCRIPT LANGUAGE="Javascript" SRC="fusioncharts/fusioncharts.js"></SCRIPT>
		<SCRIPT LANGUAGE="Javascript" SRC="fusioncharts/themes/fusioncharts.js"></SCRIPT>
     </HEAD>
     <BODY>
	 
	 <?php
                        //In this example, we show how to connect FusionCharts to a database.
                        //For the sake of ease, we've used an MySQL databases containing two
                        //tables.

                        // Connect to the DB
                        $link = connectToDB();


                        // SQL query for category labels
                        $strQueryCategories = "select distinct DATE_FORMAT(Factory_Output.DatePro,'%c-%d-%Y') as DatePro from Factory_Output order by DatePro";

                        // Query database
                        $resultCategories = mysql_query($strQueryCategories) or die(mysql_error());

                        // SQL query for factory output data
                        $strQueryData = "select Factory_Master.FactoryName, DATE_FORMAT(Factory_Output.DatePro,'%c-%d-%Y') as DatePro, Factory_Output.Quantity from Factory_Master Factory_Master, Factory_Output Factory_Output where Factory_Output.FactoryID = Factory_Master.FactoryId order by Factory_Output.FactoryID, Factory_Output.DatePro";

                        // Query database
                        $resultData = mysql_query($strQueryData) or die(mysql_error());

                        //We also keep a flag to specify whether we've to animate the chart or not.
                        //If the user is viewing the detailed chart and comes back to this page, he shouldn't
                        //see the animation again.
                        $animateChart = @$_GET['animate'];
                        //Set default value of 1
                        if ($animateChart=="")
                            $animateChart = "1";

                        //$strXML will be used to store the entire XML document generated
                        //Generate the chart element
                        $strXML = "<chart caption='Number of visitors last week' subcaption='Bakersfield Central vs Los Angeles Topanga' captionfontsize='14' subcaptionfontsize='14' subcaptionfontbold='0' palettecolors='#0075c2,#1aaf5d' bgcolor='#ffffff' showborder='0' showshadow='0' showcanvasborder='0' useplotgradientcolor='0' legendborderalpha='0'   showvalues='0' animation=' " . $animateChart . "'>";

                        // Build category XML
                        $strXML .= buildCategories ($resultCategories, "DatePro");

                        // Build datasets XML
                        $strXML .= buildDatasets ( $resultData, "Quantity", "FactoryName");

                        //Finally, close <chart> element
                        $strXML .= "</chart>";


                        //Create the chart - Pie 3D Chart with data from strXML
                        //echo renderChart("../../FusionCharts/MSLine.swf", "", $strXML, "FactorySum", 700, 400, false, false);
						 echo renderChart("MSline", "", $strXML, "FactorySum", 600, 300, false, false);


                        // Free database resource
                        mysql_free_result($resultCategories);
                        mysql_free_result($resultData);
                        mysql_close($link);


                        /***********************************************************************************************
	 * Function to build XML for categories
	 * @param	$result 			Database resource
	 * @param 	$labelField 	Field name as String that contains value for chart category labels
	 *
	 *	@return categories XML node
                         */
                        function buildCategories ( $result, $labelField ) {
                            $strXML = "";
                            if ($result) {
                                $strXML = "<categories>";
                                while($ors = mysql_fetch_array($result)) {
                                    $strXML .= "<category label='" . $ors[$labelField]. "'/>";
                                }
                                $strXML .= "</categories>";
                            }
                            return $strXML;
                        }

                        /***********************************************************************************************
	 * Function to build XML for datesets that would contain chart data
	 * @param	$result 			Database resource. The data should come ordered by a control break
	 									field which would require to identify datasets and set its value to
										dataset's series name
	 * @param 	$valueField 	Field name as String that contains value for chart dataplots
	 * @param 	$controlBreak 	Field name as String that contains value for chart dataplots
	 *
	 *	@return 						Dataset XML node
                         */
                        function buildDatasets ($result, $valueField, $controlBreak ) {
                            $strXML = "";
                            if ($result) {

                                $controlBreakValue ="";

                                while( $ors = mysql_fetch_array($result) ) {

                                    if( $controlBreakValue != $ors[$controlBreak] ) {
                                        $controlBreakValue =  $ors[$controlBreak];
                                        $strXML .= ( $strXML =="" ? "" : "</dataset>") . ( "<dataset seriesName='" . $controlBreakValue . "'>" ) ;
                                    }
                                    $strXML .= "<set value='" . $ors[$valueField] . "'/>";

                                }
                                $strXML .= "</dataset>";
                            }
                            return $strXML;

                        }

                        ?>
    
		 
        
  </BODY>
</HTML>