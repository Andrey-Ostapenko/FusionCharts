package com.example.fusionchartsample;

import java.io.IOException;
import java.io.InputStream;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.webkit.WebView;

public class WebActivity2 extends Activity {

	private WebView webView;

	@SuppressLint("SetJavaScriptEnabled")
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview);

		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		

String summary = 
		"<html>"+
"<head>"+
"<hr>"+
"FusionChart Android Native Sample"+
"<hr>"+

" <title>My First chart using FusionCharts XT - Using JavaScript</title>      "+
"<script type=\"text/javascript\" src=\"file:///android_asset/fusioncharts.js\"></script>"+"<script type=\"text/javascript\" src=\"file:///android_asset/themes/fusioncharts.theme.fint.js\"></script>"+
"</head> "+  
"<body>"+     
" <div id=\"chartContainer\">FusionCharts XT will load here!</div>"+          
"<script type=\"text/javascript\">"+
" var myChart = new FusionCharts( \"Column2D\",\"myChartId\", \"300\",\"300\", \"0\", \"1\" );"+
"myChart.setXMLData(\"<chart caption='Android Chart sample' xAxisName='Week' yAxisName='Sales' numberPrefix='$' theme='fint'><set label='Week 1' value='14800' /><set label='Week 1' value='14700' /> <set label='Week 1' value='14400' /><set label='Week 1' value='14400' /></chart>\");"+
//	"	myChart.setXMLUrl(\"file:///android_asset/Data.xml\");"+
"myChart.render(\"chartContainer\");"+      
"</script>"+  
"</body>"+ 


 "</html>";
webView.loadDataWithBaseURL(null, summary, "text/html", "utf8", null);

	
		}
	
	

}