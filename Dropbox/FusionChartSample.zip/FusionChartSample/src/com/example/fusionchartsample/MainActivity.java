package com.example.fusionchartsample;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
	protected static final boolean FirstLoad = false;


	private Button button;

	public void onCreate(Bundle savedInstanceState) {
		final Context context = this;

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	
		button = (Button) findViewById(R.id.buttonUrl);

		button.setOnClickListener(new OnClickListener() {
		@Override
			public void onClick(View arg0) {
				
			Toast.makeText(getApplicationContext(), 
                        "FusionChart Rendering", Toast.LENGTH_LONG).show();

		  	Intent intent = new Intent(context, WebViewActivity.class);
				startActivity(intent);
			}
		});
button = (Button) findViewById(R.id.button1);



		button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
			Toast.makeText(getApplicationContext(), 
                        "FusionChart Rendering", Toast.LENGTH_LONG).show();
	Intent intent = new Intent(context, WebActivity2.class);
				startActivity(intent);
			}

		});

	}

}