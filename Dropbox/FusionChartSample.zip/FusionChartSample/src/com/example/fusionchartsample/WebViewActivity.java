package com.example.fusionchartsample;

import java.io.IOException;
import java.io.InputStream;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.webkit.WebView;

public class WebViewActivity extends Activity {

	private WebView webView;

	@SuppressLint("SetJavaScriptEnabled")
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webview);

		webView = (WebView) findViewById(R.id.webView1);
		webView.getSettings().setJavaScriptEnabled(true);
		
		//DataString passed to render the chart
		
		String parentXML = "<set label='Item1' value='2' link='j-callcharts' />"+
				"<set label='Item2' value='3' link='j-callcharts' />"+
				"<set label='Item3' value='6' link='j-callcharts' />"+
				"<set label='Item4' value='1' link='j-callcharts' />";
        
        String child1XML= "<set label='Teenage' value='1250400' />"+
        		"<set label='Adult' value='1463300' />"+
        		"<set label='Mid-age' value='1050700' />"+
        		"<set label='Senior' value='491000' />";

        String child2XML= "<set label='Teenage' value='1250400' />"+
        		"<set label='Adult' value='1463300' />"+
        		"<set label='Mid-age' value='1050700' />"+
        		"<set label='Senior' value='491000' />";

        String child3XML= "<set label='Teenage' value='1250400' />"+
        		"<set label='Adult' value='1463300' />"+
        		"<set label='Mid-age' value='1050700' />"+
        		"<set label='Senior' value='491000' />";

            String summary =
               "<html>" +
               "<head>" +
               " <title>My First chart using FusionCharts XT - Using JavaScript</title>" +
               "<script type=\"text/javascript\" src=\"file:///android_asset/fusioncharts.js\"></script>" +
               "<script type=\"text/javascript\">"+
               "function callcharts() {"+
               "document.getElementById('childchart1').style.display='block';"+
               "document.getElementById('childchart2').style.display='block';"+
               "document.getElementById('childchart3').style.display='block';"+
               "child1.render();"+
               "child2.render();"+
               "child3.render();"+
               "}"+
               "</script> "+
               "</head> " +
               "<body>" +
               " <div id=\"parentchart\">FusionCharts XT will load here!</div>" +
               "<script type=\"text/javascript\">" +
               " parentchart1 = new FusionCharts( \"Bar2D\",\"parentChartID\", \"300\",\"275\", \"0\", \"1\" );" +
              "parentchart1.setXMLData(\"<chart caption='* SO - HO *' xAxisName='Area' yAxisName='Open'> " + parentXML + "</chart>\");" +
               "parentchart1.render(\"parentchart\");" +
               "</script>" +

               " <div id=\"childchart1\" style=\"display: none\">FusionCharts XT will load here!</div>" +
               "<script type=\"text/javascript\">" +
               " child1 = new FusionCharts( \"pie2d\",\"child1ID\", \"250\",\"150\", \"0\", \"1\" );" +
              "child1.setXMLData(\"<chart palettecolors='#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000' bgcolor='#ffffff' showpercentvalues='1' decimals='1' captionfontsize='14' showborder='0' showlabels='0' showvalues='0' subcaptionfontsize='14' tooltipcolor='#ffffff' tooltipbgcolor='#000000' tooltipbgalpha='80' tooltipborderradius='2' tooltippadding='5' showhovereffect='1' > " + child1XML + "</chart>\");" +
               "child1.render(\"childchart1\");" +
               "</script>" +

               " <div id=\"childchart2\" style=\"display: none\">FusionCharts XT will load here!</div>" +
               "<script type=\"text/javascript\">" +
               " child2 = new FusionCharts( \"pyramid\",\"child2ID\", \"250\",\"150\", \"0\", \"1\" );" +
              "child2.setXMLData(\"<chart bgcolor='FFFFFF' basefontcolor='333333' decimals='0' numbersuffix='M' numberprefix='$' pyramidyscale='40' showborder='0'><set value='17' name='Products' color='008ee4' />" + child2XML + "</chart>\");" +
               "child2.render(\"childchart2\");" +
               "</script>" +

               " <div id=\"childchart3\" style=\"display: none\">FusionCharts XT will load here!</div>" +
               "<script type=\"text/javascript\">" +
               " child3 = new FusionCharts( \"doughnut3d\",\"child3ID\", \"250\",\"150\", \"0\", \"1\" );" +
              "child3.setXMLData(\"<chart bgcolor='FFFFFF' basefontcolor='333333' decimals='0' numbersuffix='M' numberprefix='$' pyramidyscale='40' showborder='0'><set value='17' name='Products' color='008ee4' />" + child3XML + "</chart>\");" +
               "child3.render(\"childchart3\");" +
               "</script>" +
                "</body>" +
		"</html>";
webView.loadDataWithBaseURL(null, summary, "text/html", "utf8", null);


		}
	
	

}